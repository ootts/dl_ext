import os


def mkdir(dir):
    os.system('mkdir -p {}'.format(dir))
